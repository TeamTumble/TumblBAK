package com.tumbl.client.qna.dao;

import java.util.List;

import com.tumbl.client.qna.vo.BoardVO;
import com.tumbl.client.qna.vo.QnaVO;

public interface BoardDao {
	public List<QnaVO> boardList(QnaVO bvo);

	public int boardListCnt(QnaVO bvo);

	public int boardInsert(QnaVO bvo);

	public QnaVO boardDetail(QnaVO bvo);

	public int pwdConfirm(QnaVO bvo);

	public int boardUpdate(QnaVO bvo);

	public int boardDelete(int q_num);
}
