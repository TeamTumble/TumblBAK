package com.tumbl.client.member.controller;



import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.tumbl.client.login.service.LoginService;
import com.tumbl.client.login.vo.LoginVO;
import com.tumbl.client.member.service.MemberService;
import com.tumbl.client.member.vo.MemberVO;
import com.tumbl.client.project.vo.ProjectVO;
import com.tumbl.client.support.vo.SupportVO;

import src.service.MailService;


@Controller
@RequestMapping(value = "/member")
public class MemberController {
	Logger logger = Logger.getLogger(MemberController.class);
	

	@Autowired
	private MemberService memberService;
	

	@Autowired
    private MailService mailService;
	
	@Autowired
	private LoginService loginService;

	/**************************************************************
	 * ȸ�� ���� ��
	 **************************************************************/
	@RequestMapping(value ="/join.do", method = RequestMethod.GET)
	public String joinForm(Model model) {
		logger.info("join.do get ��Ŀ� ���� �޼��� ȣ�� ����");
		return "member/join";
	}


	/**************************************************************
	 * ȸ�� ���� ó��
	 **************************************************************/
	@RequestMapping(value ="/join.do", method = RequestMethod.POST)
	public ModelAndView memberInsert(@ModelAttribute MemberVO mvo) {
		System.out.println("�̰Ŵ� Ÿ��?");
		logger.info("join.do post ��Ŀ� ���� �޼��� ȣ�� ����");
		ModelAndView mav = new ModelAndView();
		int result = 0;
		result = memberService.memberInsert(mvo);
		
		mav.addObject("errCode", 3);
		mav.setViewName("member/join_success");
		
		return mav;
	}
	
	
	@ResponseBody
	@RequestMapping(value = "/userIdConfirm.do", method = RequestMethod.POST)
	public String userIdConfirm(@RequestParam String email) {
		System.out.println("������� �´� ���̵�");
		int result = memberService.userIdConfirm(email);
		return result + "";
	}
	
	//�������� ������ �޼ҵ�
    @ResponseBody
    @RequestMapping(value = "/mail.do", method = RequestMethod.POST, produces = "application/json" )
    private boolean sendMail(HttpSession session, @RequestParam String email) {
    	//������ȣ �����ڵ�
        int randomCode = new Random().nextInt(10000) + 1000;
        String joinCode = String.valueOf(randomCode);
        session.setAttribute("joinCode", joinCode);
 
        String subject = "ȸ������ ���� ��ȣ �Դϴ�.";
        StringBuilder sb = new StringBuilder();
        sb.append("ȸ������ ���ι�ȣ�� ").append(joinCode).append(" �Դϴ�.");
        System.out.println(joinCode);
        return mailService.send(subject, sb.toString(), "poiuripjava@gmail.com", email);
        }

	
    @ResponseBody
    @RequestMapping(value = "/check.do", method = RequestMethod.POST, produces = "application/json" )
    public int check(HttpSession session, @RequestParam String inputCode ) {
    	int result;
    	String code = (String)session.getAttribute("joinCode");
    	
    	
    	if(code.equals(inputCode)) {
    		result = 1;
    	} else {
    		result = 2;
    	}
    	return result;
    }
    
    @RequestMapping(value = "/modify.do", method = RequestMethod.GET)
	public ModelAndView memberModify(HttpSession session) {
		logger.info("modify.do get ��Ŀ� ���� �޼��� ȣ�� ����");
		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {
			mav.setViewName("member/login");
			return mav;
		}
		MemberVO vo = memberService.memberSelect(login.getEmail());
		mav.addObject("member", vo);
		mav.setViewName("member/modify");
		return mav;
	}
    
	@RequestMapping(value = "/modify.do", method = RequestMethod.POST)
	public ModelAndView memberModifyProcess(@ModelAttribute("MemberVO") MemberVO mvo, HttpSession session) {
		//ȸ������ ����
		ModelAndView mav = new ModelAndView();
		//�α��� ���ǰ��� �����´�
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {
			mav.setViewName("member/login");
			return mav;
		}
		//�α��� ���ǿ� �ִ� �̸����� ������ ���VO�� �־��ش�
		mvo.setEmail(login.getEmail());
		//���VO�ȿ� �� �̸����� ���� ����� ����Ư�ؿ´�
		MemberVO vo = memberService.memberSelect(mvo.getEmail());
		if (loginService.loginSelect(mvo.getEmail(), mvo.getOldm_pw()) == null) {
			
			mav.addObject("errCode", 1);
			mav.addObject("member", vo);
			mav.setViewName("member/modify");
			return mav;
		}
		if (memberService.memberUpdate(mvo)) {
			mav.setViewName("redirect:/member/logout.do");
			return mav;
		} else {
			mav.addObject("errCode", 2);
			mav.addObject("member", vo);
			mav.setViewName("member/modify");
			return mav;
		}
	}
	
	@RequestMapping("/delete.do")
	public ModelAndView memberDelete(HttpSession session) {
		logger.info("delete.do get��Ŀ� ���� �޼��� ȣ�� ����");
		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {
			mav.setViewName("member/login");
			return mav;
		}
		int errCode = memberService.memberDelete(login.getEmail());
		switch (errCode) {
		case 2:
			mav.setViewName("redirect:/member/logout.do");
			break;
		case 3:
			mav.addObject("errCode", 3);
			mav.setViewName("member/login");
			break;
		}
		return mav;
	}
	
	
	@RequestMapping(value = "/projectMember.do", method = RequestMethod.GET)
	public String projectCreate(ProjectVO pvo, Model model, HttpSession session) {
		logger.info("projectCreate ");
		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {
			
			return "member/login";
		}
		
		pvo.setEmail(login.getEmail());
		System.out.println(pvo.getEmail());
		List<ProjectVO> projectList = memberService.projectMember(pvo);
		System.out.println(projectList);
		model.addAttribute("projectList", projectList);
		model.addAttribute("data", pvo);
		model.addAttribute("num", pvo.getP_no());
		model.addAttribute("login", login);
		
		return "member/projectMember";
	}
	//�� �Ŀ���Ȳ
	@RequestMapping(value = "/supportMember.do", method = RequestMethod.GET)
	public String projectCreate(SupportVO svo, Model model, HttpSession session) {
		logger.info("projectCreate ");
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {		
			return "member/login";
		}
		svo.setEmail(login.getEmail());
		System.out.println(svo.getEmail());
		List<SupportVO> projectList = memberService.supportMember(svo);
		System.out.println(projectList);
		model.addAttribute("projectList", projectList);
		model.addAttribute("data", svo);
		model.addAttribute("num", svo.getP_no());
		model.addAttribute("login", login);
		
		return "member/supportMember";
	}
	
}
