package com.tumbl.admin.login.service;

import com.tumbl.admin.login.vo.AdminLoginVO;

public interface AdminLoginService {

	AdminLoginVO AdminloginSelect(AdminLoginVO lvo);

}
