package com.tumbl.client.support.service;

import com.tumbl.client.support.vo.SupportVO;

public interface SupportService {

	public int supportInsert(SupportVO svo);
	public int supportInsertPlus(SupportVO svo);
	public SupportVO supportDetail(SupportVO svo);
	public SupportVO supportSuccess(SupportVO svo);
}
