package com.tumbl.client.member.vo;

public class MemberSecurity {

	private String email;
	private String salt;

	public MemberSecurity() {
		super();
	}

	public MemberSecurity(String email, String salt) {
		super();
		this.email = email;
		this.salt = salt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	@Override
	public String toString() {
		return "MemberSecurity [email=" + email + ", salt=" + salt + "]";
	}

	
}
