/*package com.tumbl.client.support.dao;

import com.tumbl.client.support.vo.SupportVO;

public interface SupportDAO {

	public int supportInsert(SupportVO svo);
	public int supportInsertPlus(SupportVO svo);
	
	public SupportVO supportDetail(SupportVO svo);
	
	public SupportVO supportSuccess(SupportVO svo);
}
*/