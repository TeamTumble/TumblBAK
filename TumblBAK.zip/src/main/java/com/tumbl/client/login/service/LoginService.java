package com.tumbl.client.login.service;

import com.tumbl.client.login.vo.LoginVO;

public interface LoginService {
	public LoginVO userIdSelect(String email);

	public LoginVO loginSelect(String email, String m_pw);

	public int loginHistoryInsert(LoginVO lvo);

	public int loginHistoryUpdate(LoginVO lvo);

	public LoginVO loginHistorySelect(String email);

}
