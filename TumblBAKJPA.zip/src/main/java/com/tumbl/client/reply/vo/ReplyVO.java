package com.tumbl.client.reply.vo;

public class ReplyVO {
	private int r_num = 0; // ��۹�ȣ
	private int q_num = 0; // �Խ��� �۹�ȣ
	private String r_name = ""; // ��� �ۼ���
	private String r_content = ""; // ��� ����
	private String r_date = ""; // ��� �ۼ���
	private String r_pwd = ""; // ��� ��й�ȣ

	public ReplyVO() {
		super();
	}

	public ReplyVO(int r_num, int q_num, String r_name, String r_content, String r_date, String r_pwd) {
		super();
		this.r_num = r_num;
		this.q_num = q_num;
		this.r_name = r_name;
		this.r_content = r_content;
		this.r_date = r_date;
		this.r_pwd = r_pwd;
	}

	public int getR_num() {
		return r_num;
	}

	public void setR_num(int r_num) {
		this.r_num = r_num;
	}

	public int getq_num() {
		return q_num;
	}

	public void setq_num(int q_num) {
		this.q_num = q_num;
	}

	public String getR_name() {
		return r_name;
	}

	public void setR_name(String r_name) {
		this.r_name = r_name;
	}

	public String getR_content() {
		return r_content;
	}

	public void setR_content(String r_content) {
		this.r_content = r_content;
	}

	public String getR_date() {
		return r_date;
	}

	public void setR_date(String r_date) {
		this.r_date = r_date;
	}

	public String getR_pwd() {
		return r_pwd;
	}

	public void setR_pwd(String r_pwd) {
		this.r_pwd = r_pwd;
	}

	@Override
	public String toString() {
		return "ReplyVO [r_num=" + r_num + ", q_num=" + q_num + ", r_name=" + r_name + ", r_content=" + r_content
				+ ", r_date=" + r_date + ", r_pwd=" + r_pwd + "]";
	}
}
