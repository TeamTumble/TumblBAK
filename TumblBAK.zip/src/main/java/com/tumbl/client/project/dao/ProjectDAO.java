package com.tumbl.client.project.dao;

import java.util.List;

import com.tumbl.client.project.vo.ProjectVO;

public interface ProjectDAO {

	public List<ProjectVO> projectList(ProjectVO pvo);

	public List<ProjectVO> projectList_Art();

	public List<ProjectVO> projectList_Crafts();

	public List<ProjectVO> projectList_Culture();

	public List<ProjectVO> projectList_Book();

	public List<ProjectVO> projectList_Hot(ProjectVO pvo);
	public List<ProjectVO> projectList_New(ProjectVO pvo);
	
	
	public ProjectVO projectDetail(ProjectVO pvo);

	public int projectInsert(ProjectVO pvo);

	public int projectUpdate(ProjectVO pvo);
	
	public List<ProjectVO> projectList_NewA(ProjectVO pvo);
	public List<ProjectVO> projectList_HotA(ProjectVO pvo);

}
