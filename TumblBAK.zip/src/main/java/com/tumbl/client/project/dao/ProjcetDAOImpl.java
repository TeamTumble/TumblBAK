package com.tumbl.client.project.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tumbl.client.project.vo.ProjectVO;

@Repository
public class ProjcetDAOImpl implements ProjectDAO {

	@Autowired
	private SqlSession session;

	@Override
	public List<ProjectVO> projectList(ProjectVO pvo) {
		return session.selectList("projectList");
	}

	@Override
	public List<ProjectVO> projectList_Art() {
		return session.selectList("projectList_Art");
	}

	@Override
	public List<ProjectVO> projectList_Crafts() {
		return session.selectList("projectList_Crafts");
	}

	@Override
	public List<ProjectVO> projectList_Culture() {
		return session.selectList("projectList_Culture");
	}
	
	@Override
	public List<ProjectVO> projectList_Book() {
		return session.selectList("projectList_Book");
	}
	
	@Override
	public List<ProjectVO> projectList_Hot(ProjectVO pvo) {
		return session.selectList("projectList_Hot");
	}
	
	@Override
	public List<ProjectVO> projectList_New(ProjectVO pvo) {
		return session.selectList("projectList_New");
	}
	
	
	@Override
	public ProjectVO projectDetail(ProjectVO pvo) {
		return (ProjectVO) session.selectOne("projectDetail", pvo);
	}

	@Override
	public int projectInsert(ProjectVO pvo) {
		return session.insert("projectInsert", pvo);
	}

	@Override
	public int projectUpdate(ProjectVO pvo) {
		return session.update("projectUpdate", pvo);
	}

	@Override
	public List<ProjectVO> projectList_NewA(ProjectVO pvo) {
		return session.selectList("projectList_NewA");
	}

	@Override
	public List<ProjectVO> projectList_HotA(ProjectVO pvo) {
		return session.selectList("projectList_HotA");
	}

}
