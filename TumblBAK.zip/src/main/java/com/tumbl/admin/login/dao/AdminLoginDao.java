package com.tumbl.admin.login.dao;

import com.tumbl.admin.login.vo.AdminLoginVO;

public interface AdminLoginDao {

	AdminLoginVO AdminloginSelect(AdminLoginVO lvo);

}
