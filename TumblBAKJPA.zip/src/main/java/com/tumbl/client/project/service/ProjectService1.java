package com.tumbl.client.project.service;
/*package com.tumbl.client.project.service;

import java.util.List;

import com.tumbl.client.project.vo.ProjectVO1;

public interface ProjectService {

	public List<ProjectVO1> projectList(ProjectVO1 pvo);

	public List<ProjectVO1> projectList_Art();

	public List<ProjectVO1> projectList_Crafts();

	public List<ProjectVO1> projectList_Culture();

	public List<ProjectVO1> projectList_Book();

	public List<ProjectVO1> projectList_Hot(ProjectVO1 pvo);

	public List<ProjectVO1> projectList_New(ProjectVO1 pvo);

	public int projectInsert(ProjectVO1 pvo);

	public ProjectVO1 projectDetail(ProjectVO1 pvo);

	public int projectUpdate(ProjectVO1 pvo);

	public List<ProjectVO1> projectList_HotA(ProjectVO1 pvo);

	public List<ProjectVO1> projectList_NewA(ProjectVO1 pvo);

}
*/