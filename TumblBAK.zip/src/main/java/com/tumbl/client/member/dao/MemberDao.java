package com.tumbl.client.member.dao;

import java.util.List;

import com.tumbl.client.member.vo.MemberSecurity;
import com.tumbl.client.member.vo.MemberVO;
import com.tumbl.client.project.vo.ProjectVO;
import com.tumbl.client.support.vo.SupportVO;

public interface MemberDao {
	public int securityInsert(MemberSecurity set);

	public MemberSecurity securitySelect(String email);

	public int securityDelete(String email);

	public MemberVO memberSelect(String email);

	public int memberInsert(MemberVO mvo);

	public int memberUpdate(MemberVO mvo);

	public int memberDelete(String email);
	
	
	/*public ProjectVO projectMember(String email);*/
	
	public List<ProjectVO> projectMember(ProjectVO pvo);
	
	public List<SupportVO> supportMember(SupportVO svo);
	
	
	
	
}