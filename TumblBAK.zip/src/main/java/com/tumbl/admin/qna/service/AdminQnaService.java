package com.tumbl.admin.qna.service;

import java.util.List;

import com.tumbl.client.qna.vo.QnaVO;

public interface AdminQnaService {
	public List<QnaVO> qnaList(QnaVO qvo);
	
	public int qnaListCnt(QnaVO qvo); 

	public int qnaInsert(QnaVO qvo);

	public QnaVO qnaDetail(QnaVO qvo);

	public int pwdConfirm(QnaVO qvo);

	public int qnaUpdate(QnaVO qvo);

	public int qnaDelete(int q_num);
}
